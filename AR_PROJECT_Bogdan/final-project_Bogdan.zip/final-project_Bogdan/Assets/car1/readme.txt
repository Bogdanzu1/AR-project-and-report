Original LEGO 3D Model
-----------------------
Set Number          : 7800
Name                : Off Road Racer
Year                : 2009
Theme               : Racers
Pieces              : 28
Polyguns            : 20114
Corrected Materials : Yes
Animation Wheels    : Yes

Site     : 3DBrickWorld.com
Email    : info@3dbrickworld.com
Category : Car

Formats
--------
.MAX     : Autodesk 3DS Max 2018
.3DS     : Autodesk 3D Studio
.C4D     : Maxon Cinema 4D Studio R18
.DAE     : Autodesk Collada
.FBX     : Autodesk FBX
.LXF     : LEGO Digital Designer 4.3
.PNG     : Image PNG