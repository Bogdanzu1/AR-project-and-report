Original LEGO Model
-------------------
Set #    : 4096
Name     : Micro Wheels (Model G)
Year     : 2003
Theme    : Creator
Part #   : 43
Polygun #: 26230

Site     : 3DBrickWorld.com
Email    : info@3dbrickworld.com
Category : Car

Formats
-------
.MAX     : Autodesk 3DS Max 2018
.3DS     : Autodesk 3D Studio
.C4D     : Maxon Cinema 4D Studio R18
.DAE     : Autodesk Collada
.FBX     : Autodesk FBX
.LXF     : LEGO Digital Designer 4.3
.PNG     : Image PNG